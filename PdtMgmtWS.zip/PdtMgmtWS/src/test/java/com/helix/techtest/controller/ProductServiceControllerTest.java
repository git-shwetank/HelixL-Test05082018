/**
 * 
 */
package com.helix.techtest.controller;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import com.google.gson.Gson;
import com.helix.techtest.config.HibernateConfig;
import com.helix.techtest.core.MVCContextConfig;
import com.helix.techtest.entity.Event;
import com.helix.techtest.entity.Product;

/**
 * @author Shwetank
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {HibernateConfig.class,MVCContextConfig.class})
@WebAppConfiguration
@TestPropertySource("classpath:test.properties")
public class ProductServiceControllerTest {
	
	private static final Logger logger = Logger.getLogger(ProductServiceControllerTest.class);
			
	@Autowired
	Gson gson;
	
	@Autowired
	Environment env;
	
	String hostname;
	String id;
	
	String newProduct_id;
	String newProduct_timestamp;
	String newProduct_products_id;
	String newProduct_products_name;
	String newProduct_products_quantity;
	String newProduct_products_saleamount;
	
    @Before
    public void setup() throws Exception {
        hostname = env.getProperty("hostname");
        logger.info("hostname: "+hostname);
        id = env.getProperty("getProducts.id");
        logger.info("id: "+id);        
    }
    
    @Test
    public void serviceNotAvailable()
      throws ClientProtocolException, IOException {
      
       String name = "TestEventId"+Calendar.getInstance().getTimeInMillis();
       HttpUriRequest request = new HttpGet( hostname+"/PdtMgmtWS/"+name+"/getProducts.html");
     
       HttpResponse httpResponse = HttpClientBuilder.create().build().execute( request );
     
       Assert.assertNotEquals(httpResponse.getStatusLine().getStatusCode(),HttpStatus.SC_OK);
    }
    
    @Test
    public void addProduct() throws Exception{
    	
    	/*
    	{
		  "id": "(string) unique id of the event",
		  "timestamp": "(timestamp) utc timestamp of the event",
		  "products": [
		    {
		      "id": "(long) id of the product",
		      "name": "(string) name of the product",
		      "quantity": "(integer) quantity of the product",
		      "sale_amount": "(double) total sale amount"
		    }
		  ]
		} 
    	*/
    	Event event = new Event();
    	Date newDate = new Date();
    	event.setId("TestEventId"+newDate.getTime());
    	event.setTimestamp(newDate);
    	
    	Set<Product> products = new HashSet<Product>();
    	Product product = new Product();
    	product.setId(0);
    	product.setName("Test Product");
    	product.setQuantity(10);
    	product.setSale_amount(23.45);
    	products.add(product);
    	event.setProducts(products);
    	
    	String eventJson = gson.toJson(event);

    	logger.info("Event JSON: "+eventJson);
    	
    	StringEntity entity = new StringEntity(eventJson);
    	
    	HttpPost httpPost = new HttpPost( hostname+"/PdtMgmtWS/postProducts.html");
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/json");
        
        HttpResponse httpResponse = HttpClientBuilder.create().build().execute( httpPost );

        Assert.assertEquals(httpResponse.getStatusLine().getStatusCode(), HttpStatus.SC_OK);        
    }
    
    @Test
    public void addProducts() throws Exception{
    	
    	/*
    	{
		  "id": "(string) unique id of the event",
		  "timestamp": "(timestamp) utc timestamp of the event",
		  "products": [
		    {
		      "id": "(long) id of the product",
		      "name": "(string) name of the product",
		      "quantity": "(integer) quantity of the product",
		      "sale_amount": "(double) total sale amount"
		    }
		  ]
		} 
    	*/
    	Event event = new Event();
    	Date newDate = new Date();
    	event.setId("TestEventId"+newDate.getTime());
    	event.setTimestamp(newDate);

    	Set<Product> products = new HashSet<Product>();
    	
    	Product product = new Product();
    	//product.setId(0);
    	product.setName("Test Product");
    	product.setQuantity(10);
    	product.setSale_amount(23.45);
    	products.add(product);
    	
    	Product product1 = new Product();
    	//product1.setId(0);
    	product1.setName("Test Product");
    	product1.setQuantity(10);
    	product1.setSale_amount(23.45);
    	products.add(product1);
    	
    	Product product2 = new Product();
    	//product2.setId(0);
    	product2.setName("Test Product");
    	product2.setQuantity(10);
    	product2.setSale_amount(23.45);
    	products.add(product2);
    	
    	event.setProducts(products);
    	
    	String eventJson = gson.toJson(event);

    	logger.info("Event JSON: "+eventJson);
    	
    	StringEntity entity = new StringEntity(eventJson);
    	
    	HttpPost httpPost = new HttpPost( hostname+"/PdtMgmtWS/postProducts.html");
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/json");
        
        HttpResponse httpResponse = HttpClientBuilder.create().build().execute( httpPost );

        Assert.assertEquals(httpResponse.getStatusLine().getStatusCode(), HttpStatus.SC_OK);        
    }
    
    @Test
    public void getProducts() throws Exception{
    	
    	HttpUriRequest request = new HttpGet( hostname+"/PdtMgmtWS/"+id+"/getProducts.html");
        
        HttpResponse httpResponse = HttpClientBuilder.create().build().execute( request );
        
        String jsonResponse = EntityUtils.toString(httpResponse.getEntity());
        
        logger.info("Retrieved JSON Response: "+jsonResponse);
        
        Assert.assertEquals(httpResponse.getStatusLine().getStatusCode(), HttpStatus.SC_OK);
        
    }
    
    @Test
    public void getAllProducts() throws Exception{
    	HttpUriRequest request = new HttpGet( hostname+"/PdtMgmtWS/getAllProducts.html");
        
        HttpResponse httpResponse = HttpClientBuilder.create().build().execute( request );
        
        String jsonResponse = EntityUtils.toString(httpResponse.getEntity());
        
        logger.info("Retrieved JSON Response: "+jsonResponse);
        
        Assert.assertEquals(httpResponse.getStatusLine().getStatusCode(), HttpStatus.SC_OK);
    	
    }

}
