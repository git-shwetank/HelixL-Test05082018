package com.helix.techtest.core;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.XmlViewResolver;

import com.google.gson.Gson;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages={"com.helix.techtest"})
public class MVCContextConfig extends WebMvcConfigurerAdapter{
		
	@Bean
	ViewResolver viewResolver(){
		InternalResourceViewResolver rptAppView = new InternalResourceViewResolver();
		rptAppView.setViewClass(org.springframework.web.servlet.view.JstlView.class);
		rptAppView.setPrefix("/WEB-INF/view/");
		rptAppView.setSuffix(".jsp");
		return rptAppView;
	}
		
	@Bean
	Gson getGson(){
		return new Gson();
	}
		
	//more resources & controller definitions to be continued
}
