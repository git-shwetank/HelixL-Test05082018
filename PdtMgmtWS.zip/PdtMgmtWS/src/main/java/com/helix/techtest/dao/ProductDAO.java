/**
 * 
 */
package com.helix.techtest.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.exception.JDBCConnectionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.helix.techtest.entity.Product;

/**
 * @author Shwetank
 *
 */
@Service
public class ProductDAO {
	
	private static final Logger logger = Logger.getLogger(ProductDAO.class);
	
	@Autowired
	SessionFactory sessionFactory;
	
	public List<Product> getAll() {
		List<Product> list = null;
		Session session = null;
		Transaction tx = null;
		try{
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			Query query = session.createQuery("from com.h2h.entity.Product");
			
			list = query.list();
		} catch(JDBCConnectionException ce){
			logger.info("Error while retrieving all records from PRODUCT. Possibly due to problems while communicating with the database (may also include incorrect JDBC setup)",ce);
		} catch(HibernateException he){
			logger.info("Error while retrieving all records from PRODUCT",he);
		} catch(Exception e){
			logger.info("Error while retrieving all records from PRODUCT",e);
		}finally{
			if(tx!=null && session!=null){
				tx.commit();
				session.close();
			}
		}
		return list;
	}

}
