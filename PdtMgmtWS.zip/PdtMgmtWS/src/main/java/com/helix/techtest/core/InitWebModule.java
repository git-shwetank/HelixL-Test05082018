package com.helix.techtest.core;

import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import com.helix.techtest.config.HibernateConfig;

public class InitWebModule implements WebApplicationInitializer{
	
	public static final Logger logger = Logger.getLogger(InitWebModule.class);

	@Override
	public void onStartup(ServletContext container) throws ServletException {
		
		logger.info("Application Startup begins!!");
		
		container.setInitParameter("log4jConfigLocation", "/WEB-INF/log4j.xml");
		container.addListener(org.springframework.web.util.Log4jConfigListener.class);
		
		AnnotationConfigWebApplicationContext listeners = new AnnotationConfigWebApplicationContext();
		//listeners.register(HibernateConfig.class);
		listeners.register(HibernateConfig.class);
		
		try{
			listeners.refresh();	
		} catch(BeansException be){
			logger.error("Application Startup failed!!", be);
		} catch(IllegalStateException ise){
			logger.error("Application Startup failed!!", ise);
		} catch(Exception e){
			logger.error("Application Startup failed!!", e);
		}
		container.addListener(new ContextLoaderListener(listeners));
		logger.info("Application Core Initialization Successful!!");
		
		logger.info("Starting to load WEB INFRA!!");
		AnnotationConfigWebApplicationContext mvcContext = new AnnotationConfigWebApplicationContext();
		mvcContext.register(MVCContextConfig.class);
		
		ServletRegistration.Dynamic dispatcher = container.addServlet("dispatcher", new DispatcherServlet(mvcContext));
		dispatcher.setLoadOnStartup(1);
		
		Set<String> mappingConflicts = dispatcher.addMapping("*.html");
		 
		if (!mappingConflicts.isEmpty()) {
			for (String s : mappingConflicts) {
				System.out.println("Mapping conflict: " + s);
				//logger.error("Mapping conflict: " + s);
			}
			throw new IllegalStateException("'appServlet' cannot be mapped to '/' under Tomcat versions <= 7.0.14");
		}
	}
}
