/**
 * 
 */
package com.helix.techtest.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.NonUniqueResultException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.exception.JDBCConnectionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.helix.techtest.entity.Event;
import com.helix.techtest.entity.Product;

/**
 * @author Shwetank
 *
 */
@Service
public class EventDAO {
	
	private static final Logger logger = Logger.getLogger(EventDAO.class);
	
	@Autowired
	SessionFactory sessionFactory;
	
	public List<Event> getAll() {
		List<Event> list = null;
		Session session = null;
		Transaction tx = null;
		try{
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			Query query = session.createQuery("from com.helix.techtest.entity.Event");
			
			list = query.list();
		} catch(JDBCConnectionException ce){
			logger.info("Error while retrieving all records from EVENT. Possibly due to problems while communicating with the database (may also include incorrect JDBC setup)",ce);
		} catch(HibernateException he){
			logger.info("Error while retrieving all records from EVENT",he);
		} catch(Exception e){
			logger.info("Error while retrieving all records from PRODUCT",e);
		}finally{
			if(tx!=null && session!=null){
				tx.commit();
				session.close();
			}
		}
		return list;
	}
	
	public boolean save(Event event){
		boolean status = false;
		Session session = null;
		Transaction tx = null;
		
		try{
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			
			String id = (String)session.save(event);
			
			tx.commit();

			if(id!=null){
				status = true;
			}
			
		} catch(JDBCConnectionException ce){
			logger.info("Error while saving record to EVENT. Possibly due to problems while communicating with the database (may also include incorrect JDBC setup)",ce);
			if(tx!=null){
				tx.rollback();
			}
		} catch(HibernateException he){
			logger.info("Error while saving a record to EVENT",he);
			if(tx!=null){
				tx.rollback();
			}
		} catch(Exception e){
			logger.info("Error while saving event to Database!!",e);
			if(tx!=null){
				tx.rollback();
			}
		} finally{
			if(session!=null){
				session.close();
			}
		}
		return status;
	}

	public Event getById(String id) {
		Event event = null;
		Session session = null;
		Transaction tx = null;
		try{
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			Query query = session.createQuery("from com.helix.techtest.entity.Event e where e.id = :id");
			query.setString("id", id);
			
			event = (Event)query.uniqueResult();
		} catch(JDBCConnectionException ce){
			logger.info("Error while retrieving all records from EVENT. Possibly due to problems while communicating with the database (may also include incorrect JDBC setup)",ce);
		} catch(NonUniqueResultException nure){
			logger.info("Error while retrieving unique records from EVENT.",nure);
		} catch(HibernateException he){
			logger.info("Error while retrieving record from EVENT",he);
		} catch(Exception e){
			logger.info("Error while retrieving all records from PRODUCT",e);
		}finally{
			if(tx!=null && session!=null){
				tx.commit();
				session.close();
			}
		}
		return event;
	}

}
