/**
 * 
 */
package com.helix.techtest.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.helix.techtest.dao.EventDAO;
import com.helix.techtest.dao.ProductDAO;
import com.helix.techtest.entity.Event;
import com.helix.techtest.entity.Product;
import com.helix.techtest.vo.EventVO;
import com.helix.techtest.vo.ProductVO;

/**
 * @author Shwetank
 *
 */
@RestController
public class ProductServiceController {	
	
	public static final Logger logger = Logger.getLogger(ProductServiceController.class);

	@Autowired
	EventDAO eventDAO;

	@Autowired
	ProductDAO productDAO;

	@Autowired
	Gson gson;

	@RequestMapping(path="/getAllProducts.html",method=RequestMethod.GET)
	@ResponseBody String getProducts(HttpServletRequest request){
		String response = null;
		
		List<Event> events = eventDAO.getAll();
		
		logger.info("Events Count: "+events.size());
				
		if(events!=null){
			
			List<EventVO> newEvents = new ArrayList<EventVO>();
			
			for(Event event: events){
				EventVO eventVO = new EventVO();
				
				BeanUtils.copyProperties(event, eventVO);
				eventVO.setProducts(null);
				
				if(event.getProducts()!=null && event.getProducts().size()>0){
					for(Product product : event.getProducts()){
						
						if(eventVO.getProducts()==null){
							eventVO.setProducts(new HashSet<ProductVO>());
						}
						ProductVO productVO = new ProductVO();
						BeanUtils.copyProperties(product, productVO);
						eventVO.getProducts().add(productVO);
					}
				}
				newEvents.add(eventVO);
			}
			
			response = gson.toJson(newEvents);
			logger.info(response);
		}
		
		return response;		
	}
	
	@RequestMapping(path="/{id}/getProducts.html",method=RequestMethod.GET)
	@ResponseBody String getProducts(HttpServletRequest request, @PathVariable(value="id") String eventId){
		String response = null;
		
		Event event = eventDAO.getById(eventId);
				
		if(event!=null){
			
			EventVO newEvent = new EventVO();
			
			BeanUtils.copyProperties(event, newEvent);
			newEvent.setProducts(null);
			
			for(Product product: event.getProducts()){
				ProductVO newProduct = new ProductVO();
				BeanUtils.copyProperties(product, newProduct);
				if(newEvent.getProducts()==null){
					newEvent.setProducts(new HashSet<ProductVO>());
				}
				newEvent.getProducts().add(newProduct);
			}
			response = gson.toJson(newEvent);
			logger.info(response);
		} else{
			response = gson.toJson(new Event());
		}
		
		return response;		
	}
	
	@RequestMapping(path="/postProducts.html",method=RequestMethod.POST)
	@ResponseBody String postProducts(HttpServletRequest request, @RequestBody Event event){
		String response = null;
		
		logger.info("event to JSON"+gson.toJson(event));
		    	
		if(eventDAO.save(event)){
			//parse response as updated event
		} else{
			event = new Event();
		}
				
		if(event!=null){
			response = gson.toJson(event);
			logger.info(response);
		}
		
		return response;		
	}
	
}
