/**
 * 
 */
package com.helix.techtest.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.id.Assigned;

/**
 * @author Shwetank
 *
 */
@Entity
@Table(name = "EVENT")
public class Event implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6642505157926632688L;

	@Id
	@Column(name = "ID", nullable = false)
	private String id;
	
	@Column(name = "TIMESTAMP")
	private Date timestamp;
	
	@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinTable(name = "EVENT_PRODUCT", joinColumns= {@JoinColumn(name = "EVENT_ID", referencedColumnName="ID")}, inverseJoinColumns= {@JoinColumn(name = "PRODUCT_ID", referencedColumnName= "ID")})
	Set<Product> products;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}
	
}
