/**
 * 
 */
package com.helix.techtest.vo;

import java.util.Date;
import java.util.Set;

/**
 * @author Shwetank
 *
 */
public class EventVO {

	private String id;
	
	private Date timestamp;
	
	Set<ProductVO> products;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Set<ProductVO> getProducts() {
		return products;
	}

	public void setProducts(Set<ProductVO> products) {
		this.products = products;
	}

}
