/**
 * 
 */
package com.helix.techtest.vo;

/**
 * @author Shwetank
 *
 */
public class ProductVO {

	private long id;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
}
